﻿using System.Net.Http;
using System.Windows.Controls;

namespace WpfApp.Models
{
    public class Site
    {
        public int SiteId { get; set; }
        public string Ville { get; set; }

    }
   
}

