﻿namespace WpfApp.Models
{
    public class Service
    {
        public int ServiceId { get; set; }
        public string Nom { get; set; }

    }
}
