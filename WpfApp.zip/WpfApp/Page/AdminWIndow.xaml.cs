﻿using System;
using System.Net.Http;
using System.Windows;

namespace WpfApp.Page
{
    public partial class AdminWIndow : Window
    {
        HttpClient client = new HttpClient();
        public AdminWIndow()
        {
            client.BaseAddress = new Uri("https://localhost:44324/api/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json")
                );
            InitializeComponent();
        }
        //Site
        private void BtnGestionSites_Click(object sender, RoutedEventArgs e)
        {
            GestionSitesWindow gestionSitesWindow = new GestionSitesWindow();
            gestionSitesWindow.Show();
        }
        //Service
        private void BtnGestionServices_Click(object sender, RoutedEventArgs e)
        {
            GestionServicesWindow gestionServicesWindow = new GestionServicesWindow();
            gestionServicesWindow.Show();
        }
        //Salarie
        private void BtnGestionSalaries_Click(object sender, RoutedEventArgs e)
        {
            GestionSalariesWindow gestionSalariesWindow = new GestionSalariesWindow();
            gestionSalariesWindow.Show();
        }
    }
}

