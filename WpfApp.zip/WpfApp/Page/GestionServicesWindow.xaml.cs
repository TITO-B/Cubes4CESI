﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Windows;
using service = WpfApp.Models.Service;




namespace WpfApp.Page
{
    public partial class GestionServicesWindow : Window
    {

        HttpClient client = new HttpClient();
        public GestionServicesWindow()
        {
            client.BaseAddress = new Uri("https://localhost:44324/api/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json")
                );
            InitializeComponent();
        }

        private void BtnLoadService_Click(object sender, RoutedEventArgs e)
        {
            this.GetService();
        }

        //Recuperer les informations de base
        private async void GetService()
        {
            lblMessage.Content = "";
            var response = await client.GetStringAsync("service");
            var service = JsonConvert.DeserializeObject<List<service>>(response);
            dgService.DataContext = service;
        }

        #region Ajouter
        private void btnSaveService_Click(object sender, RoutedEventArgs e)
        {
            var service = new service();
            if (string.IsNullOrEmpty(txtServiceId.Text))
            {
                service.ServiceId = 0;
            }
            else
            {
                service.ServiceId = Convert.ToInt32(txtServiceId.Text);
            }


            service.Nom = txtNom.Text;

            if (service.ServiceId == 0)
            {
                this.SaveService(service);

                lblMessage.Content = "Service enregistrer";


            }
            else
            {
                this.UpdateService(service);
                lblMessage.Content = "Service enregistrer";
            }
            txtServiceId.Text = "";
            txtNom.Text = "";
        }
        private async void SaveService(service service)
        {
            await client.PostAsJsonAsync("service", service);
        }
        #endregion

        #region Editer
        void btnEditService(object sender, RoutedEventArgs e)
        {
            service service = ((FrameworkElement)sender).DataContext as service;
            txtServiceId.Text = service.ServiceId.ToString();
            txtNom.Text = service.Nom;
        }
        private async void UpdateService(service service)
        {
            await client.PutAsJsonAsync("service", service);
        }
        #endregion

        #region Supprimer
        void btnDeleteService(object sender, RoutedEventArgs e)
        {

            service service = ((FrameworkElement)sender).DataContext as service;
            this.DeleteService(service.ServiceId);
            txtServiceId.Text = service.ServiceId.ToString(); 
            txtNom.Text = "";
            lblMessage.Content = "Service supprimer"; 
        }
        private async void DeleteService(int serviceId)
        {
            await client.DeleteAsync("service?id=" + serviceId);
        }
        #endregion

    }
}

