﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Windows;
using WpfApp.Models;

namespace WpfApp.Page
{
    public partial class GestionSalariesWindow : Window
    {
        private HttpClient client = new HttpClient();

        public GestionSalariesWindow()
        {
            InitializeComponent();
            client.BaseAddress = new Uri("https://localhost:44324/api/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json")
            );
        }
        
        private void BtnLoadSalarie_Click(object sender, RoutedEventArgs e)
        {
            this.GetSalarie();
        }

        //Recuperer les informations de base
        private async void GetSalarie()
        {
            lblMessage.Content = "";
            var response = await client.GetStringAsync("salarie");
            var salarie = JsonConvert.DeserializeObject<List<Salarie>>(response);
            dgSalarie.DataContext = salarie;
        }
        
        #region Ajouter
        private void BtnSaveSalarie_Click(object sender, RoutedEventArgs e)
        {
            var salarie = new Models.Salarie();
            if (string.IsNullOrEmpty(txtSalarieId.Text))
            {
                salarie.SalarieId = 0;
            }
            else
            {
                salarie.SalarieId = Convert.ToInt32(txtSalarieId.Text);
            }


            salarie.Nom = txtNom.Text;
            salarie.Prenom = txtPrenom.Text;
            salarie.TelephoneFixe = txtTelephoneFixe.Text;
            salarie.TelephonePortable = txtTelephonePortable.Text;
            salarie.Email = txtEmail.Text;
            salarie.SiteId = Convert.ToInt32(txtSiteId.Text);
            salarie.ServiceId =  Convert.ToInt32(txtServiceId.Text);

            if (salarie.SalarieId == 0)
            {
                this.SaveSalarie(salarie);

                lblMessage.Content = "Salarié enregistrer";


            }
            else
            {
                this.UpdateSalarie(salarie);
                lblMessage.Content = "Salarié enregistrer";
            }
            txtSalarieId.Text = "";
            txtNom.Text = "";
            txtPrenom.Text = "";
            txtTelephoneFixe.Text = "";
            txtTelephonePortable.Text = "";
            txtEmail.Text = "";
            txtSiteId.Text = "";
            txtServiceId.Text = "";
        }

        private async void SaveSalarie(Models.Salarie salarie)
        {
            await client.PostAsJsonAsync("salarie", salarie);
        }
        #endregion

        #region Editer
        void BtnEditSalarie(object sender, RoutedEventArgs e)
        {
            Salarie salarie = ((FrameworkElement)sender).DataContext as Models.Salarie;
            txtSalarieId.Text =  salarie.SalarieId.ToString();
            txtNom.Text = salarie.Nom;
            txtPrenom.Text = salarie.Prenom;
            txtTelephoneFixe.Text = salarie.TelephoneFixe;
            txtTelephonePortable.Text = salarie.TelephonePortable;
            txtEmail.Text = salarie.Email;

            txtSiteId.Text =  salarie.SiteId.ToString();
            txtServiceId.Text =salarie.ServiceId.ToString();
        }

        private async void UpdateSalarie(Models.Salarie salarie)
        {
            await client.PutAsJsonAsync("salarie", salarie);
        }
        #endregion

        #region Supprimer
        void BtnDeleteSalarie(object sender, RoutedEventArgs e)
        {
            Salarie salarie = ((FrameworkElement)sender).DataContext as Models.Salarie;
            this.DeleteSalarie(salarie.SalarieId);
            txtSalarieId.Text = salarie.SalarieId.ToString(); 
            txtNom.Text = "";
            txtPrenom.Text = "";
            txtTelephoneFixe.Text = "";
            txtTelephonePortable.Text = "";
            txtEmail.Text = "";
            txtSiteId.Text = "";
            txtServiceId.Text = "";
            lblMessage.Content = "Salarié supprimer"; 
        }
        private async void DeleteSalarie(int SalarieId)
        {
            await client.DeleteAsync("salarie?id=" + SalarieId);
        }
        #endregion

    }
}
