﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Windows;
using Site = WpfApp.Models.Site;


namespace WpfApp.Page
{
    public partial class GestionSitesWindow : Window
    {

        HttpClient client = new HttpClient();
        public GestionSitesWindow()
        {
            client.BaseAddress = new Uri("https://localhost:44324/api/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json")
                );
            InitializeComponent();
        }

        private void BtnLoadSite_Click(object sender, RoutedEventArgs e)
        {
            this.GetSite();
        }

        //Recuperer les informations de base
        private async void GetSite()
        {
            lblMessage.Content = "";
            var response = await client.GetStringAsync("site");
            var site = JsonConvert.DeserializeObject<List<Site>>(response);
            dgSite.DataContext = site;
        }
        
        #region Ajouter
        private void btnSaveSite_Click(object sender, RoutedEventArgs e)
        {
            var site = new Site();

            if (string.IsNullOrEmpty(txtSiteId.Text))
            {
                site.SiteId = 0;
            }
            else
            {
                site.SiteId = Convert.ToInt32(txtSiteId.Text);
            }

            site.Ville = txtVille.Text;

            if (site.SiteId == 0)
            {
                this.SaveSite(site);
                lblMessage.Content = "Site enregistrer";
            }
            else
            {
                this.UpdateSite(site);
                lblMessage.Content = "Site enregistrer";
            }

            txtSiteId.Text = ""; 
            txtVille.Text = "";  
        }
        private async void SaveSite(Site site)
        {
            await client.PostAsJsonAsync("Site", site);
        }

        #endregion

        #region Editer
        void btnEditSite(object sender, RoutedEventArgs e)
        {
            Site site = ((FrameworkElement)sender).DataContext as Site;
            txtSiteId.Text = site.SiteId.ToString();
            txtVille.Text = site.Ville;
        }
        private async void UpdateSite(Site site)
        {
            await client.PutAsJsonAsync("Site", site);
        }
        #endregion

        #region Supprimer
        void btnDeleteSite(object sender, RoutedEventArgs e)
        {
            Site site = ((FrameworkElement)sender).DataContext as Site;
            this.DeleteSite(site.SiteId);
            txtSiteId.Text = site.SiteId.ToString(); 
            txtVille.Text = ""; 
            lblMessage.Content = "Site Supprimer"; 
        }
        private async void DeleteSite(int SiteId)
        {
            await client.DeleteAsync("Site/?id=" + SiteId);
        }
        #endregion

    }
}

