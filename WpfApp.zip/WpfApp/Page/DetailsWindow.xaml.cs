﻿using System;
using System.Net.Http;
using System.Windows;
using WpfApp.Models;

namespace WpfApp.Page
{
    public partial class DetailsWindow : Window
    {
        private readonly Salarie selectedSalarie;
        
        //Afficher les details
        public DetailsWindow(Salarie selectedSalarie)
        {
            
            InitializeComponent();
            this.selectedSalarie = selectedSalarie;
            DataContext = this.selectedSalarie;

        }
    }
}
