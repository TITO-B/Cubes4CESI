﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Windows;
using System.Windows.Input;
using WpfApp.Models;
using WpfApp.Page;

namespace WpfApp
{
    public partial class MainWindow : Window
    {
        public ICommand OpenAdminPageCommand { get; }

        private List<Site> sites;
        private List<Service> services;
        private string originalSearchText;
        private Site originalSelectedSite;
        private Service originalSelectedService;


        public MainWindow()
        {
            InitializeComponent();
            client.BaseAddress = new Uri("https://localhost:44324/api/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json")
            );
            OpenAdminPageCommand = new RelayCommand(OpenAdminPage, CanOpenAdminPage);
            DataContext = this;

            // Charger les listes de sites et de services
            LoadSites();
            LoadServices();
            // Afficher tous les salariés au démarrage sans filtres
            GetSalarie(); 

        }

        private HttpClient client = new HttpClient();

        #region Combinaison de touche
        // Methode pour la combinaison de touche
        private void OpenAdminPage()
        {
            AdminWIndow adminWindow = new AdminWIndow();
            adminWindow.ShowDialog();
        }

        private bool CanOpenAdminPage()
        {
            return true;
        }
        #endregion

        #region Charger les Site & Service
        private async void LoadSites()
        {
            var response = await client.GetStringAsync("site");
            sites = JsonConvert.DeserializeObject<List<Site>>(response);
            RechercheSite.ItemsSource = sites;
            originalSearchText = txtSearch.Text;
            originalSelectedSite = RechercheSite.SelectedItem as Site;
        }

        private async void LoadServices()
        {
            var response = await client.GetStringAsync("service");
            services = JsonConvert.DeserializeObject<List<Service>>(response);
            RechercheService.ItemsSource = services;
            originalSelectedService = RechercheService.SelectedItem as Service;
        }
        #endregion

        #region Filtres

        // Actualiser la liste des salariés lorsqu'un filtre change
        private void FilterChanged(object sender, RoutedEventArgs e)
        {
            if (IsLoaded) 
                GetSalarie();
        }

        private void btnReinitialiserFiltres_Click(object sender, RoutedEventArgs e)
        {
            ReinitialiserFiltres();
            GetSalarie();
        }

        private void ReinitialiserFiltres()
        {
            txtSearch.Text = originalSearchText;
            RechercheSite.SelectedItem = originalSelectedSite;
            RechercheService.SelectedItem = originalSelectedService;
        }
        #endregion

        private async void GetSalarie()
        {
            // Récupérer les valeurs des filtres
            string nomFiltre = txtSearch.Text;
            int? siteIdFiltre = (RechercheSite.SelectedItem as Site)?.SiteId;
            int? serviceIdFiltre = (RechercheService.SelectedItem as Service)?.ServiceId;

            string apiUrl = $"salarie/filtered?siteId={siteIdFiltre}&serviceId={serviceIdFiltre}&nomContient={nomFiltre}";
            
            try
            {
                
                var response = await client.GetStringAsync(apiUrl);
                var salarie = JsonConvert.DeserializeObject<List<Salarie>>(response);

                // Récupérer les détails du service et du site pour chaque salarié
                foreach (var s in salarie)
                {
                    var serviceResponse = await client.GetAsync($"service/{s.ServiceId}");
                    if (serviceResponse.IsSuccessStatusCode)
                    {
                        Service service = await serviceResponse.Content.ReadAsAsync<Service>();
                        s.NomService = service?.Nom;
                    }

                    var siteResponse = await client.GetAsync($"site/{s.SiteId}");
                    if (siteResponse.IsSuccessStatusCode)
                    {
                        Site site = await siteResponse.Content.ReadAsAsync<Site>();
                        s.VilleSite = site?.Ville;
                    }
                }

                dgResults.DataContext = salarie;
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show($"Aucun salarié ne correspond a ces filtres.");
            }
        }
        void btnDetail(object sender, RoutedEventArgs e)
        {
            if (dgResults.SelectedItem != null && dgResults.SelectedItem is Salarie selectedSalarie)
            {
                DetailsWindow detailsWindow = new DetailsWindow(selectedSalarie);
                detailsWindow.Show();
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner un salarié pour afficher les détails.");
            }
        }

    }
}
